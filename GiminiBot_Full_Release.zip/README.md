# GiminiBot

A Telegram bot powered by Google Gemini (gemini-1.5-flash). Easily deployable on PythonAnywhere.

## 🔧 Features

- Gemini API integration
- Telegram buttons
- Support & donation options
- Ready to deploy

## 🚀 Deployment

1. Upload files to [PythonAnywhere](https://www.pythonanywhere.com/)
2. Set your `YOUR_TELEGRAM_BOT_TOKEN` and `YOUR_GEMINI_API_KEY` in `bot.py`
3. Run the bot

## 💬 Contact

Created by [@AmirullohOriginal](https://t.me/AmirullohOriginal)
