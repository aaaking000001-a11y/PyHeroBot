import logging
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import google.generativeai as genai
import os

# Gemini API key
genai.configure(api_key="YOUR_GEMINI_API_KEY")
model = genai.GenerativeModel("gemini-1.5-flash")

# Enable logging
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# Keyboard
keyboard = [
    [KeyboardButton("💬 Ask Gemini")],
    [KeyboardButton("📞 Support"), KeyboardButton("❤️ Donate")],
    [KeyboardButton("👨‍💻 Support Creator")]
]
reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# Start command
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Welcome to GiminiBot!\nChoose an option below:", reply_markup=reply_markup)

# Main reply handler
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = update.message.text
    if text == "💬 Ask Gemini":
        await update.message.reply_text("Please send your question for Gemini.")
    elif text == "📞 Support":
        await update.message.reply_text("Contact support: support@example.com")
    elif text == "❤️ Donate":
        await update.message.reply_text("You can support me via @AmirullohOriginal")
    elif text == "👨‍💻 Support Creator":
        await update.message.reply_text("Thank you! Follow the creator: @AmirullohOriginal")
    else:
        try:
            response = model.generate_content(text)
            await update.message.reply_text(response.text)
        except Exception as e:
            await update.message.reply_text("Error: " + str(e))

def main() -> None:
    application = Application.builder().token("YOUR_TELEGRAM_BOT_TOKEN").build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.run_polling()

if __name__ == "__main__":
    main()
